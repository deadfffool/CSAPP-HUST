﻿#include<stdio.h>
int a = 1;


int main()
{
	int b;
	b = a;
	return 0;
}
